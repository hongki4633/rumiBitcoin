# LumiBitcoin (LUMBTC) 🌕

A light-born Bitcoin clone with mining, limited to 21 million.

## 🔹 Token Information

- Name: LumiBitcoin
- Symbol: LUMBTC
- Total Supply: 21,000,000 (with 8 decimals)
- Mining: Available via `mine()` (1-time per wallet)

## 🔹 Deployment

- Network: Sepolia Testnet
- Owner Address: `0x0D8Cbb49E78415C083493fBA1B4C4d41F1a44748`

## 🔹 How to Mine

1. Call `mine()` from Remix or frontend
2. Requires small gas
3. Get 10 LUMBTC

---

“Where Bitcoin ends, Lumi begins.”  
